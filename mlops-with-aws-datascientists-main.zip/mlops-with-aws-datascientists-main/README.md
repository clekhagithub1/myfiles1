# This is a Repository for MLOps Course with AWS 
For errata, please drop an email to - murthy@manifoldailearning.in

Connect with Instructor on - https://www.linkedin.com/in/nachiketh-murthy/

Happy Learning

