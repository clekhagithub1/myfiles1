# Hands On

## Pre-requisite
- Upload all the files in the dataset folder into the S3 bucket
- Open the Data Wrangler and Follow the steps mentioned in the video

![Alt text](image.png)