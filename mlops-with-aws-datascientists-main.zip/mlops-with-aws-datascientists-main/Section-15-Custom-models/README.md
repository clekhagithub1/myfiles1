# Activity on Bring your Own Container

- Edit and add the new trust policy for sagemaker execution role using contents of `trust-policy.json`
- add the inline policy using the contents from `iam-policy.json`
- Follow the instructions on the video